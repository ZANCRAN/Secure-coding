#include <exception>
class Myexception :
    public std::exception
{
};

