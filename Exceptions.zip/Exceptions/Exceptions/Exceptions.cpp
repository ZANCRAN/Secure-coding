// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include "Myexception.cpp"
using namespace std;



bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    //throw std::exception();
    throw std::invalid_argument("Invalid Argument when running Even More Custom Application Logic.");

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try 
    {
         if (do_even_more_custom_application_logic())
            {
             std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
            }
    }
    catch (std::exception& e)
    {
        std::cout << "Do even more custom  application logic failed :" << std::endl;
        
        cerr << e.what() << endl;;
    }



    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    std::cout << "Leaving Custom Application Logic." << std::endl;
    // create custom exception object and throw custom exception
    Except myexcept("Couldn't do what you were expecting", -12, -34);
    throw myexcept;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    if (den == 0) // exception will be throw if the denominator equal zero
    {
        throw std::runtime_error("Attempted to divide a number by zero");
    }
    return (num / den);
    
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;
    try
    {
        auto result = divide(numerator, denominator); // throw runtime_error exception if denominator equal zero
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error& re) 
    { 
       // display error message
        cerr << re.what() << endl;
    }
}
   

int main()

{
    std::cout << "Exceptions Tests!" << std::endl;
    //myexception except;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try
    {
       
        do_division();
        do_custom_application_logic();
      


    }
    

    // catch custom exception
    catch (const Except& myexcept)
    {
        std::cerr << myexcept.what() << "\nError number: " << myexcept.getErrorNumber()
            << "\nError offset: " << myexcept.getErrorOffset() << endl;
        return -1;
    }

    // catch a standard exception
    catch (const std::invalid_argument& in)
    {
        cerr << in.what() << endl;
        return -1;
    }

    // handle uncaught exception, catch all-handler
    catch (...)
    {
        std::cout << "catch all others exception" << endl;
        return -1;
    }
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu